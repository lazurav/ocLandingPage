<?php
// Heading
$_['heading_title'] 		= 'Landing Sitemap';

// Text
$_['text_feed'] 			= 'Feed';
$_['text_success'] 			= 'Module settings updated!';
$_['text_edit'] 			= 'Edit Landing Sitemap';
$_['text_extension'] 		= 'Extensions';

// Entry
$_['entry_status'] 			= 'Status:';
$_['entry_data_feed'] 		= 'Online generation address (better to configure CRON):';
$_['text_link'] 			= 'After generation (!) The feed is saved to:';

// Error
$_['error_permission'] 		= 'You do not have permission to manage this module!';
