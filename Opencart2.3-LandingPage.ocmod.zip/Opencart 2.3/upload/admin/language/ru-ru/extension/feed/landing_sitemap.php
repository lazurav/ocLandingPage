<?php
// Heading
$_['heading_title']    			= 'Landing Sitemap';

// Text
$_['text_feed']          		= 'Каналы продвижения';
$_['text_success']          	= 'Настройки модуля обновлены!';
$_['text_edit']          		= 'Редактировать Landing Sitemap';
$_['text_extension']         	= 'Модули';

// Entry
$_['entry_status']          	= 'Статус:';
$_['entry_data_feed']          	= 'Адрес онлайн генерации (лучше настроить CRON):';
$_['text_link']          		= 'После генерации (!) Фид сохраняется по адресу:';

// Error
$_['error_permission']          = 'У вас нет прав для управления этим модулем!';
